package APIProject;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import java.util.concurrent.TimeUnit;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Test;
import io.restassured.response.ValidatableResponse;


/*
3)Validate the response for a request with POST method instead of GET method.
-	HTTP Status code 405 
-	HTTP 405 Method Not Allowed
Request: mentioned above
Response:
<?xml version="1.0" encoding="UTF-8" standalone="yes"?><errorMainDTO><error><message>HTTP 405 Method Not Allowed</message><code>405</code></error></errorMainDTO>
*/


@Description("Test Case with POST Method"
		+ "To Verify response for a request with POST Method.")

public class Test_005 {

	 final static String url="https://api.intigral-ott.net/popcorn-api-rs-7.9.17/v1/promotions?apikey=webB2BGDMSTGExy0sVDlZMzNDdUy";
	 
	 
@Test
	    public static void main(String args[]) {

	      getResponseBody();
	      getResponseStatus();
	      getResponseHeaders();
	      getResponseTime();
	      getResponseContentType();
	      getResponseStatusLine();
	 }

@Test
	    //This will fetch the response body as is and log it. given and when are optional here
	    public static void getResponseBody(){

	   ValidatableResponse ResponseBody = given().when().post(url).then().log().body();
	
	   System.out.println("Response Body is: " + ResponseBody);
	   
	    }

@Test
        public static void getResponseStatus(){
        int statusCode= given()
          .when().get(url).getStatusCode();
        System.out.println("The response status is "+statusCode);
        given().when().get(url).then().assertThat().statusCode(405);
} 
	    
@Test
		 public static void getResponseStatusLine(){	    
	    String statusLine = given()
	            .when().get(url).getStatusLine();
	    System.out.println("The response status line is "+statusLine);
	    given().when().get(url).then().assertThat().toString();
	

}

@Test
	 public static void getResponseHeaders(){
	 	   System.out.println("The headers in the response "+
	 	                   get(url).then().extract()
	 	           .headers());
	 	}

@Test
	 public static void getResponseTime(){
	 	  System.out.println("The time taken to fetch the response "+get(url)
	 	         .timeIn(TimeUnit.MILLISECONDS) + " milliseconds");
	 	}

@Test
	 public static void getResponseContentType(){
	 	   System.out.println("The content type of response "+
	 	           get(url).then().extract()
	 	              .contentType());
	 	}	  
}
