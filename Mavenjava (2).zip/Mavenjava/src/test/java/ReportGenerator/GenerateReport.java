package ReportGenerator;

import java.io.File;

public class GenerateReport {

	public void generateExcelReport(String ExcelReport) {
		/*
		String path = GenerateReport.class.getClassLoader().getResource("./").getPath();
      
        
        File xmlFile = new File(path + "../test-output/testng-results.xml");
        
        System.out.println(xmlFile.isFile());
	}

	public static void main(String[] args) {
     
		new GenerateReport().generateExcelReport("");  */
		
	}
	
	
}
