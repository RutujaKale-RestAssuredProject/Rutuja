package RaynaB2B_Tour;

import static io.restassured.RestAssured.given;
import org.springframework.context.annotation.Description;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;

@Description("Test Case - API Automation for TourList API")

public class TestCase_003 {

	@BeforeTest
	   public static void main(String args[]) {
		
		
	     getResponseBody();
	}

	@Test
	   //This will fetch the response body as is and log it. given and when are optional here
	   public static void getResponseBody(){
		
		String InputJson = "{\r\n"
				+ "    \"tourId\":33,\r\n"
				+ "    \"contractId\":330, \r\n"
				+ "}";
		

		        RestAssured.baseURI = "http://raynaapi.raynatours.com";

		        Response response = given().contentType("application/json")
		                .header("Authorization","Bearer eyJhbGciOiJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGRzaWctbW9yZSNobWFjLXNoYTI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiIzODllNWEzNS05OTJkLTRjYzMtYjVjYy04YmZjNmZlY2E2MmMiLCJVc2VySWQiOiIzNTkwNiIsIlVzZXJUeXBlIjoiQWdlbnQiLCJQYXJlbnRJRCI6IjAiLCJFbWFpbElEIjoibWF5dXJpLnBAdGVjaG5vaGVhdmVuLmNvbSIsImlzcyI6Imh0dHA6Ly9yYXluYWFwaS5yYXluYXRvdXJzLmNvbSIsImF1ZCI6Imh0dHA6Ly9yYXluYWFwaS5yYXluYXRvdXJzLmNvbSJ9.TR-aA10804jrF9VQNDgOBpq56fVySNMhpn5oRJ12gic")
		                .and()
		                .body(InputJson)
		                .when()
		                .post("/api/Tour/touroptionstaticdata")
		                .then()
		                .extract().response();
		        
		        System.out.println(response.asPrettyString());
		        System.out.println(response.getBody().asString());
		        System.out.printf("The Response Time is ");
		        System.out.println(response.getTime());	
		        System.out.println("Tour options static data API - PASSED");
	    
	   }

}
