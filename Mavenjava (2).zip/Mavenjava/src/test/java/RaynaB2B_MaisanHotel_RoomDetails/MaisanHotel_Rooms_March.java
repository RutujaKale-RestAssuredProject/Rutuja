package RaynaB2B_MaisanHotel_RoomDetails;

import static io.restassured.RestAssured.given;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.jayway.jsonpath.JsonPath;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class MaisanHotel_Rooms_March {
	
@BeforeTest
   public static void main(String args[]) {
		
     Rooms_March ();
}

@Test
   //This will fetch the response body as is and log it. given and when are optional here
   public static void Rooms_March () {
	
	String InputJson = "{\r\n"
			+ "    \"Token\":\"eyJhbGciOiJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGRzaWctbW9yZSNobWFjLXNoYTI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJkZGEyMDlmNy0wYThiLTQyN2UtOWU3Zi1kMTExZDNjZjM5ZWYiLCJVc2VySWQiOiIyMzY4MCIsIlVzZXJUeXBlIjoiQWdlbnQiLCJQYXJlbnRJRCI6IjAiLCJFbWFpbElEIjoiYW1tYXJAd2l0aGluZWFydGguY29tIiwiaXNzIjoiaHR0cDovL3JheW5hYXBpLnJheW5hdG91cnMuY29tIiwiYXVkIjoiaHR0cDovL3JheW5hYXBpLnJheW5hdG91cnMuY29tIn0.S90eAJ9xprnpD3wqHfUqm1bLipKhWkcK68n2O2titt8\",\r\n"
			+ "    \"Request\": {\r\n"
			+ "        \"Rooms\": [\r\n"
			+ "            {\r\n"
			+ "                \"RoomNo\": 1,\r\n"
			+ "                \"NoofAdults\": 2,\r\n"
			+ "                \"NoOfChild\": 0,\r\n"
			+ "                \"ChildAge\": []\r\n"
			+ "            }\r\n"
			+ "        ],\r\n"
			+ "        \"CityID\": \"212101\",\r\n"
			+ "        \"CheckInDate\": \"03-01-2022\",\r\n"
			+ "        \"CheckOutDate\": \"03-02-2022\",\r\n"
			+ "        \r\n"
			+ "        \"NoofNights\": \"1\",\r\n"
			+ "        \"Nationality\": \"India\",\r\n"
			+ "        \"Filters\": {\r\n"
			+ "            \"IsRecommendedOnly\": \"0\",\r\n"
			+ "            \"IsShowRooms\": \"1\",\r\n"
			+ "            \"IsOnlyAvailable\": \"1\",\r\n"
			+ "            \"StarRating\": {\r\n"
			+ "                \"Min\": 1,\r\n"
			+ "                \"Max\": 5\r\n"
			+ "            },\r\n"
			+ "            \"HotelIds\": \"39731006\"\r\n"
			+ "        }\r\n"
			+ "    },\r\n"
			+ "    \"AdvancedOptions\": {\r\n"
			+ "        \"Currency\": \"AED\"\r\n"
			+ "    }\r\n"
			+ "}";
	

	        RestAssured.baseURI = "http://raynaapi.raynatours.com";

	        Response response = given()
	                .header("Content-type", "application/json")
	                .and()
	                .body(InputJson)
	                .when()
	                .post("/api/XConnect/Availability")
	                .then()
	                .extract().response();
	        
	        String json = response.asString();
	        
	    	// fetch first array
	    	String HotelCountMarch = JsonPath.read(json, "$.availabilityRS.hotelResult[0].hotelOption").toString();
	    	System.out.println(HotelCountMarch);
    
   }

}
