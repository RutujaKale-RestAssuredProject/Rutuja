package APIProject;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import java.util.concurrent.TimeUnit;
import org.springframework.context.annotation.Description;
import org.testng.annotations.Test;


/*
 Mocky for Json Response for GET Method = https://run.mocky.io/v3/338d66cc-caae-41cb-bbb4-1293aacd4033
 */


@Description("Test Case - Valid apikey "
		+ "To Verify Response Body, Status Code, Response Time, Headers, Content-Type")


public class Test_001 {

   final static String url="https://api.intigral-ott.net/popcorn-api-rs-7.9.17/v1/promotions?apikey=webB2BGDMSTGExy0sVDlZMzNDdUyZ";
@Test
   public static void main(String args[]) {

     getResponseBody();
     getResponseStatus();
     getResponseHeaders();
     getResponseTime();
     getResponseContentType();
}

@Test
   //This will fetch the response body as is and log it. given and when are optional here
   public static void getResponseBody(){

  given().when().get(url).then().log().body();
  
   }

@Test
public static void getResponseStatus(){
   int statusCode= given()
           .when().get(url).getStatusCode();
   System.out.println("The response status is "+statusCode);
   given().when().get(url).then().assertThat().statusCode(200);
}

@Test
public static void getResponseHeaders(){
	   System.out.println("The headers in the response "+
	                   get(url).then().extract()
	           .headers());
	}

@Test
public static void getResponseTime(){
	  System.out.println("The time taken to fetch the response "+get(url)
	         .timeIn(TimeUnit.MILLISECONDS) + " milliseconds");
	}

@Test
public static void getResponseContentType(){
	   System.out.println("The content type of response "+
	           get(url).then().extract()
	              .contentType());
	}

}
